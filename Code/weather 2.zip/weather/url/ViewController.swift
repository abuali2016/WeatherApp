//
//  ViewController.swift
//  url
//
//  Created by OJP on 1/29/17.
//  Copyright © 2017 OJP. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate {
    
    @IBOutlet weak var citypicker: UIPickerView!
    @IBOutlet weak var cityoutlet: UILabel!
    @IBOutlet weak var tempoutlet: UILabel!
     var cityNamesArray = ["Muscat","Paris","London","Moscow","Dubai"]

    override func viewDidLoad() {
        super.viewDidLoad()
        citypicker.delegate = self
        citypicker.dataSource = self
        
        
        // Do any additional setup after loading the view, typically from a nib.
          }

    
   
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return cityNamesArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return cityNamesArray[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        downloadDataForCity(name: cityNamesArray[row])
       
    }
    
    func downloadDataForCity(name:String)
    {
        let url = URL(string: "http://api.openweathermap.org/data/2.5/find?q=\(name)&units=metric&appid=e562ac227e7c220c0357118155ad1e61")
        let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error != nil
            {
                print("Error")
            }
            else
            {
                //if let mydata = data
                
                do{
                    let jsonObject = try JSONSerialization.jsonObject(with: data!, options: []) as! [String:AnyObject]
                    //print(jsonObject)
                    
                    for item in jsonObject["list"] as! NSArray
                    {
                        print(item)
                        
                        let temp = (item  as AnyObject).value(forKeyPath: "main.temp") as! NSNumber
                        print(temp)
                        self.tempoutlet.text = String(describing: temp)
                        let name = (item  as AnyObject).value(forKeyPath: "name") as! String
                        print(name)
                        self.cityoutlet.text = name
                        
                    }
                    
                    
                }
                catch{
                    
                }
                
            }
        }
        task.resume()
       

        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}

